<!-- TAMPILAN HOME -->

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
  <style>
    body{
      background-color:#4C5D76;
    }
  </style>
</head>
<body>
<div class="row">
          <div class="col-lg-12">
            <h1>HOME <small>Page</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.php?page=barang"><i class="icon-dashboard"></i> Get Started</a></li>
            </ol>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-12">
            Selamat Datang Di Halaman Home Page !!
          </div>
        </div>
</body>
</html>