<?php
$host = "localhost";
$user = "root";
$pass = "";
$database = "belajar";
?>